$(document).ready(function() {
    $('#example').DataTable();
    $('#example1').DataTable();
    $('#example2').DataTable();
    $('#example3').DataTable();

    $(this).bind("contextmenu", function(e) {
		e.preventDefault();
	});

	// var base_url = '<?php echo base_url(); ?>';
 //    var aa = base_url+'home/getResults';
 //    alert(aa);
    
 //    $("#usnSearch").click(function(){
 //            event.preventDefault();
 //            $("#res").hide();
 //            $("#process").show();
                    
 //            var usn = $("#usn").val(); 
             
 //            $.ajax({'type':'POST',
 //                'url':base_url+'home/getResults',
 //                'data':{'usn':usn},
 //                'dataType':'text',
 //                'cache':false,
 //                'success':function(data){
 //                    $("#process").hide();
 //                    $("#res").show();
 //                    $("#res").html(data);
 //                }
 //            });
 //        });


} );

// PDFObject.embed("../assets/files/TEQIP-III/Gallery.pdf", "#TEQIP-III-Gallery");

